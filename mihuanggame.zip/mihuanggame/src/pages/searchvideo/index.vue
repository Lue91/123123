<template>
  <div class="container page">
    <van-nav-bar title="搜索" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back" />
      </template>
    </van-nav-bar>
    <form class="search-bar" action="/">
      <van-search  background="linear-gradient(270deg, #e6c3a1, #7e5678)"
                   placeholder="搜索热门视频"
                   @search="SearchVideo"
                   shape="round"
                   v-model="searchText"
                   :clearable="true"
                   clear-trigger="always">
      </van-search>
    </form>
    <div class="main-content">
      <van-pull-refresh style="height: 100%;" v-model="isLoading" @refresh="onRefresh">
        <div class="hot-recommend-div">
          <van-list v-model="loading" :finished="finished" :immediate-check="false" finished-text="没有更多了" @load="onLoad"
                    style="width: 100%;">
            <div class="list-item">
              <div class="movie-list-item" v-for="(v, key) in videolist" :key="key" @click="toPlayVideo(v.id)">
                <van-image class="cover_img" round :src="v.vod_pic">
                  <template v-slot:loading>
                    <van-loading type="circular" />
                  </template>
                </van-image>
                <div class="movie-list-item-bottom">
                  <div class="movie-time-div">
                    <span>{{ v.vod_name }}</span>
                    <span>播放:{{ v.count }}</span>
                  </div>
                </div>
              </div>
            </div>
          </van-list>

        </div>
      </van-pull-refresh>
    </div>
  </div>
</template>
<script>
import {Toast} from 'vant';
export default {
  data() {
    // console.log();
    let text = this.$router.history.current.query.text;
    if (typeof text === 'undefined') {
      text = '';
    } else {
      text = decodeURIComponent(text);
    }
    return {
      searchText: text,
      loading: false,
      finished: false,
      isLoading: false,
      videolist: []
    }
  },
  methods: {
    SearchVideo() {
      console.log('Search for', this.searchText);
      return this.$http({
        method: 'get',
        data: {
          key_word: encodeURIComponent(this.searchText)
        },
        url: 'video_search'
      }).then(res => {
        this.videolist = res.data.data;
        console.log(res.data.data);
      });
    },
    back() {
      window.history.back();
    },
    onRefresh() {
      this.SearchVideo().then(() => {
        this.loading = false;
        this.isLoading = false;
        this.finished = true;
        Toast('刷新成功');
      });
    },
    onLoad() {
      this.SearchVideo().then(() => {
        this.finished = true;
      });
    },
    toPlayVideo(id) {
      if (!localStorage.getItem('token')) {
        this.$router.push({ path: '/Login' })
      } else {
        this.$router.push({ path: '/PlayVideo?id=' + id })
      }
    }
  },
  created() {
    this.onLoad();
  }
}
</script>

<style lang="less" scoped>
@import "../../assets/css/base.css";

.container .main-content {
  overflow: auto;
  height: 100%;
}

::v-deep .van-pull-refresh__track .van-pull-refresh__head * {
  color: #000;
  font-size: 35px;
}

.movie-list-tab .hot-recommend-div {
  height: 100%;
  margin: 10px auto;
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
  flex-wrap: wrap;
  //overflow: auto;
}

.list-item {
  display: flex;
  width: calc(100% - 50px);
  margin: 10px auto;
  align-items: flex-start;
  justify-content: flex-start;
  flex-wrap: wrap;
}

.list-item .movie-list-item:nth-child(odd) {
  margin-right: 20px;
}

.movie-list-item .cover_img {
  border-radius: 20px;
  width: 335px;
  height: 290px;
}

.movie-list-item {
  margin-bottom: -10px;
}

.list-item .movie-list-item-bottom {
  position: relative;
  width: 335px;
  bottom: 42px;
}

.list-item .movie-list-item-bottom .movie-time-div {
  background-color: rgba(0, 0, 0, .4);
}

.list-item .movie-list-item-bottom>div {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.list-item .movie-list-item-bottom .movie-time-div .van-count-down {
  color: #fff;
}

.list-item .movie-list-item .movie-time-div span:first-child {
  overflow: hidden;
  white-space: nowrap;
  width: 180px;
  padding-left: 8px;
  font-size: 25px;
}

.list-item .movie-time-div {
  color: #fff;
  border-radius: 0 0 20px 20px;
  height: 35px;
}

::v-deep .van-field__control {
  height: 56px;
  width: 92%;
  font-size: 28px;
}

@icon-size: 42px;
::v-deep .van-icon-search {
  height: @icon-size;
  width: @icon-size;
  transform: translateY(5px);
}

::v-deep .van-icon-clear {
  height: @icon-size;
  width: @icon-size;
}


::v-deep .van-icon-clear::before {
  line-height: @icon-size;
  width: @icon-size;
  font-size: @icon-size;
}

::v-deep .van-icon-search::before {
  line-height: @icon-size;
  width: @icon-size;
  font-size: @icon-size;
}
</style>
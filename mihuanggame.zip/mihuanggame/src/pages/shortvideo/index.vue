<template>
  <div :style="`--visible-height: ${visibleHeight};`" class="black-bg">
    <iframe :src="`/short/index.html?uid=${uid}`" title="shortVideo"></iframe>
  </div>
</template>

<script>
export default {
  data() {
    return {
      uid: localStorage.getItem('token'),
      visibleHeight: '100vh'
    };
  },
  methods : {
    listenWinHeight() {
      this.visibleHeight = document.documentElement.clientHeight + 'px';
    }
  },
  created() {
    this.listenWinHeight();
    console.log(window);
    window.addEventListener('resize', this.listenWinHeight);
    if (!localStorage.getItem('token')) {
      this.$router.push('/Login')
    }
    document.getElementsByTagName('body')[0].style = 'overflow: hidden'; // 禁用浏览器自带刷新
  },
  beforeDestroy() {
    console.log('leaving....');
    window.removeEventListener('resize', this.listenWinHeight);
    document.getElementsByTagName('body')[0].style = '';
  }
}
</script>
<style scoped lang="less">
@tabbar-height: 110px;
.black-bg {
  background-color: black;
  max-height: calc(var(--visible-height) - @tabbar-height);
}

iframe {
  border: 0;
  margin: 0;
  height: calc(var(--visible-height) - @tabbar-height);
  width: 100vw;
  background-color: black;
}
</style>
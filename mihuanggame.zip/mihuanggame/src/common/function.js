
export default{
    isLogin:function(_this){
        if(!_this.$store.getters.getLoginValue){console.log('exec');
            return _this.$router.push("Login")
            
        }
    }
}
